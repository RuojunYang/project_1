from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User
from django.core.validators import RegexValidator


class SignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.type = User.Types.CUSTOMER 
        if commit:
            user.save()
        return user
    
class RentVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)

class ReportVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)

class PaymentForm(forms.Form):
    card_number = forms.CharField(
        max_length=16,
        min_length=13,
        required=True,
        label='Card Number',
        validators=[RegexValidator(r'^\d{13,19}$', 'Enter a valid card number')]
    )
    expiry_date = forms.DateField(
        required=True,
        label='Expiry Date (MM/YY)',
        input_formats=['%m/%y'],
        widget=forms.DateInput(format='%m/%y', attrs={'placeholder': 'MM/YY'})
    )
    cvv = forms.CharField(
        max_length=4,
        min_length=3,
        required=True,
        label='CVV',
        validators=[RegexValidator(r'^\d{3}$', 'Enter a valid CVV')]
    )
    amount = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        required=True,
        label='Amount'
    )

class ChargeVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)

class RepairVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)

class MoveVehicleForm(forms.Form):
    id = forms.CharField(label="Vehicle ID", max_length=15, required=True)
    
    lat = forms.DecimalField(
        max_digits=10,
        decimal_places=7,
        required=True,
        label='Latitude'
    )
    lon = forms.DecimalField(
        max_digits=10,
        decimal_places=7,
        required=True,
        label='Longitude'
    )

class GenerateReportForm(forms.Form):
    start_time = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        label='Report Start Time'
    )
    end_time = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        label='Report End Time'
    )