from django.apps import AppConfig


class EVehicleShareSystemConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "E_Vehicle_Share_System"
