from django.urls import path
from . import views

urlpatterns = [

    path('', views.home, name='home'),

    path('select_login/', views.select_login, name="select_login"),
    path('login/', views.login_func, name="login"),
    path('login_customer/', views.login_customer, name="login_customer"),
    path('login_operator/', views.login_operator, name="login_operator"),
    path('login_manager/', views.login_manager, name="login_manager"),
    path('signup/', views.signup_func, name="signup"),
    path('logout/', views.logout_func, name="logout"),
    path('after_login_home/', views.after_login_home, name="after_login_home"),
]
