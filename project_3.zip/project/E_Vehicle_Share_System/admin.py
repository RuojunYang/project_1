# python manage.py makemigrations
# python manage.py migrate
from django.contrib import admin
from .models import Base_User, VehicleData, CUSTOMER, OPERATOR, MANAGER

# Register your models here.
admin.site.register(Base_User)
admin.site.register(VehicleData)
admin.site.register(CUSTOMER)
admin.site.register(OPERATOR)
admin.site.register(MANAGER)