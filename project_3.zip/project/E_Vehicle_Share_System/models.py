from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from django.db.models.signals import post_save
from django.dispatch import receiver
# Create your models here.

class Base_User(AbstractBaseUser):

    class Types(models.TextChoices):
        CUSTOMER = "CUSTOMER", "Customer"
        OPERATOR = "OPERATOR", "Operator"
        MANAGER = "MANAGER", "Manager"


    base_type = Types.CUSTOMER

    type = models.CharField(
        max_length=20, choices=Types.choices, default=Types.CUSTOMER
    )

    Username = models.CharField(unique=True, max_length=50)
    
    def save(self, *arg, **kwargs):
        if not self.pk:
            self.type = base_type
            return super().save(*args, **kwargs)
    

class VehicleData(models.Model):
    Vehicle_ID = models.IntegerField(primary_key=True)
    Charging_points = models.CharField(max_length=100)
    City_locations = models.CharField(max_length=100)
    Customer_ID = models.IntegerField()
    Status = models.CharField(max_length=100)

class CUSTOMER(Base_User):
    class Meta:
        proxy = True
    
class OPERATOR(Base_User):
    class Meta:
        proxy = True
    
class MANAGER(Base_User):
    class Meta:
        proxy = True