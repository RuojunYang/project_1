from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, PasswordChangeForm
from django.contrib.auth import login, logout
from django.contrib.auth import update_session_auth_hash

#def members(request):
#    return HttpResponse("Hello world!")

def home(request):
    return render(request, "home.html")

def select_login(request):
    return render(request, "select_login.html")

def login_func(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect("after_login_home")
    else:
        form = AuthenticationForm()
    return render(request, "login.html", { "form": form })

def login_customer(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect("after_login_home")
    else:
        form = AuthenticationForm()
    return render(request, "login_customer.html", { "form": form })

def login_operator(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect("after_login_home")
    else:
        form = AuthenticationForm()
    return render(request, "login_operator.html", { "form": form })

def login_manager(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect("after_login_home")
    else:
        form = AuthenticationForm()
    return render(request, "login_manager.html", { "form": form })

def signup_func(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("login")
    else:
        form = UserCreationForm()
    return render(request, "signup.html", {"form": form})

def logout_func(request):
    if request.method == "POST":
        logout(request)
        return redirect("home")

def password_change(request):
    if request.method == "POST":
        form = PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)


def after_login_home(request):
    return render(request, "after_login_home.html")
    
