# python manage.py makemigrations
# python manage.py migrate
# python manage.py createsuperuser
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Customer, Operator, Manager, Vehicle
from django.utils import timezone
import numpy as np
from geopy.geocoders import Nominatim

lon_max = -4.05
lon_min = -4.41	
lat_max = 55.94
lat_min = 55.73

def get_address(latitude, longitude):
    geolocator = Nominatim(user_agent="geoapi")
    location = geolocator.reverse((latitude, longitude), exactly_one=True)
    try :
        return location.address
    except Exception as e:
        print(e)

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'first_name', 'last_name', 'type',)
    list_filter = ('type', 'is_superuser', 'is_active')

    search_fields = ('username', 'first_name', 'last_name')
    ordering = ('username',)

@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ('id', 'is_in_use', 'customer')
    search_fields = ('id', 'customer__user__username')
    list_filter = ('is_in_use',)


# create test data
# customer
new_user, created_user = User.objects.get_or_create(
    username='customer',
    defaults={
        'password': 'password123',
        'type': User.Types.CUSTOMER
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

customer_instance, created_customer = Customer.objects.get_or_create(
    user=new_user,
    defaults={
        'is_using_vehicle': False, 
        'start_using_time': 1729333602, 
        'end_using_time': 1729333902, 
        'charge': '110',
    }
)
# operator
new_user, created_user = User.objects.get_or_create(
    username='operator',
    defaults={
        'password': 'password123',
        'type': User.Types.OPERATOR
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

operator_instance, created_customer = Operator.objects.get_or_create(
    user=new_user,
    defaults={
    }
)

# manager
new_user, created_user = User.objects.get_or_create(
    username='manager',
    defaults={
        'password': 'password123',
        'type': User.Types.MANAGER
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

manager_instance, created_customer = Manager.objects.get_or_create(
    user=new_user,
    defaults={
    }
)

# lon_max = -4.05
# lon_min = -4.41	
# lat_max = 55.94
# lat_min = 55.73

for i in range(2):
    try:
        lat = np.random.uniform(lat_max, lat_min)
        lon = np.random.uniform(lon_max, lon_min)
        location = get_address(lat, lon)
        vehicle, created_vehicle = Vehicle.objects.get_or_create(
            id = i+10000,
            defaults={
                'is_in_use': False,
                'status_type': Vehicle.STATUS_TYPES.NOT_USING,
                'vehicle_type': Vehicle.VEHICLE_TYPES.BIKE,
                'lat': lat,
                'lon': lon,
                'location': location
            }
        )
        print(vehicle, vehicle.vehicle_type, vehicle.lat, vehicle.lon)
    except Exception as e:
        print(e)
for i in range(2):
    try:
        lat = np.random.uniform(lat_max, lat_min)
        lon = np.random.uniform(lon_max, lon_min)
        location = get_address(lat, lon)
        vehicle, created_vehicle = Vehicle.objects.get_or_create(
            id = i+20000,
            defaults={
                'is_in_use': False,
                'status_type': Vehicle.STATUS_TYPES.DEFECTIVE,
                'vehicle_type': Vehicle.VEHICLE_TYPES.SCOOTER,
                'lat': lat,
                'lon': lon,
                'location': location,
                'battery_level': 50
            }
        )
        print(vehicle, vehicle.vehicle_type, vehicle.lat, vehicle.lon)
    except Exception as e:
        print(e)

for i in range(2):
    try:
        lat = np.random.uniform(lat_max, lat_min)
        lon = np.random.uniform(lon_max, lon_min)
        location = get_address(lat, lon)
        vehicle, created_vehicle = Vehicle.objects.get_or_create(
            id = i+30000,
            defaults={
                'is_in_use': False,
                'status_type': Vehicle.STATUS_TYPES.NOT_USING,
                'vehicle_type': Vehicle.VEHICLE_TYPES.SCOOTER,
                'lat': lat,
                'lon': lon,
                'location': location,
                'battery_level': 0
            }
        )
        print(vehicle, vehicle.vehicle_type, vehicle.lat, vehicle.lon)
    except Exception as e:
        print(e)

print(customer_instance)
print(customer_instance.charge)
print(customer_instance.is_using_vehicle)
print(customer_instance.vehicle)
