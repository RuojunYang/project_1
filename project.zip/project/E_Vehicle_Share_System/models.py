from django.db import models

# Create your models here.

class UserData(models.Model):
    User_id = models.IntegerField(primary_key=True)
    Username = models.CharField(max_length=20)
    Passowrd = models.CharField(max_length=20)
    User_type = models.CharField(max_length=100)
    Renting_starting_time = models.IntegerField()
    Renting_ending_time = models.IntegerField()
    Rent_vehicle_ID = models.IntegerField()
    Charge = models.IntegerField()

class VehicleData(models.Model):
    Vehicle_ID = models.IntegerField(primary_key=True)
    Charging_points = models.CharField(max_length=100)
    City_locations = models.CharField(max_length=100)
    Customer_ID = models.IntegerField()
    Status = models.CharField(max_length=100)
