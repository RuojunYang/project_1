from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib import messages
from .models import UserData
from django.contrib.auth import authenticate
from django.contrib.auth.forms import UserCreationForm

#def members(request):
#    return HttpResponse("Hello world!")

def home(request):
    return render(request, "home.html")


def login(request):
    # return render(request, "login.html", {"form": form})
    return render(request, "login.html")

def signup(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        print(form.is_valid, form.is_valid, form.is_valid)
        print(form.is_valid, form.is_valid, form.is_valid)
        print(form.is_valid, form.is_valid, form.is_valid)
        if form.is_valid():
            form.save()
            return redirect("login")
    else:
        form = UserCreationForm()
    return render(request, "signup.html", {"form": form})

def logout(request):
    #return render(request, "logout.html", {"form": form})
    return render(request, "logout.html")


def after_login_home(request):
    return render(request, "after_login_home.html")
    