# python manage.py makemigrations
# python manage.py migrate
# python manage.py createsuperuser
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Customer, Operator, Manager, Vehicle

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'first_name', 'last_name', 'type',)
    list_filter = ('type', 'is_superuser', 'is_active')

    search_fields = ('username', 'first_name', 'last_name')
    ordering = ('username',)

@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ('id', 'is_in_use', 'customer')
    search_fields = ('id', 'customer__user__username')
    list_filter = ('is_in_use',)


# create test data
# customer
new_user, created_user = User.objects.get_or_create(
    username='customer',
    defaults={
        'password': 'password123',
        'type': User.Types.CUSTOMER
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

customer_instance, created_customer = Customer.objects.get_or_create(
    user=new_user,
    defaults={
        'is_using_vehicle': True,
        'start_using_time': 1729333602,
        'end_using_time': 1729333902
    }
)
# operator
new_user, created_user = User.objects.get_or_create(
    username='operator',
    defaults={
        'password': 'password123',
        'type': User.Types.OPERATOR
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

customer_instance, created_customer = Operator.objects.get_or_create(
    user=new_user,
    defaults={
    }
)

# manager
new_user, created_user = User.objects.get_or_create(
    username='manager',
    defaults={
        'password': 'password123',
        'type': User.Types.MANAGER
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

customer_instance, created_customer = Manager.objects.get_or_create(
    user=new_user,
    defaults={
    }
)
# customers and vehicle
for i in range(5):
    new_user, created_user = User.objects.get_or_create(
        username='user_' + str(i),
        defaults={'password': 'password123'}
    )

    if created_user:
        new_user.set_password('password123')
        new_user.save()

    customer = User.objects.get(username='user_' + str(i))
    
    if i % 2 == 0:
        try:
            vehicle, created_vehicle = Vehicle.objects.get_or_create(
                id = i+10000,
                is_in_use=True,
                customer=customer
            )
            customer_instance, created_customer = Customer.objects.get_or_create(
                user=new_user,
                defaults={
                    'is_using_vehicle': True,
                    'vehicle': vehicle,
                    'start_using_time': 1729333602,
                    'end_using_time': 1729333902
                }
            )
        except Exception as e:
            print(e)
    else:
        try:
            vehicle, created_vehicle = Vehicle.objects.get_or_create(
                id = i+10000,
                is_in_use=False,
            )
            customer_instance, created_customer = Customer.objects.get_or_create(
                user=new_user,
                defaults={
                    'is_using_vehicle': False,
                }
            )
        except Exception as e:
            print(e)
    user = User.objects.get(username='user_' + str(i),)
    
    customer = Customer.objects.get(user=user)
    vehicle = customer.vehicle

    print(f"Customer {user.username} using vehicle: {vehicle}")
