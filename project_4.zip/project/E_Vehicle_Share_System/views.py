from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth import login, logout
from django.contrib.auth import update_session_auth_hash
from .models import User
from .forms import SignupForm
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.http import JsonResponse
from .models import Vehicle, Customer, Operator, Manager


#def members(request):
#    return HttpResponse("Hello world!")

def home(request):
    return render(request, "home.html")

def select_login(request):
    return render(request, "select_login.html")

def login_customer(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()

            if user.type == User.Types.CUSTOMER:
                login(request, user)
                return redirect("after_login_customer")
            else:
                messages.error(request, "You are not authorized to log in as a Customer.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, "login_customer.html", {"form": form})

def login_operator(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()

            if user.type == User.Types.OPERATOR:
                login(request, user)
                return redirect("after_login_operator")
            else:
                messages.error(request, "You are not authorized to log in as a Operator.")
    else:
        form = AuthenticationForm()
    
    return render(request, "login_operator.html", {"form": form})

def login_manager(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()

            if user.type == User.Types.MANAGER:
                login(request, user)
                return redirect("after_login_manager")
            else:
                messages.error(request, "You are not authorized to log in as a Manager.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, "login_manager.html", {"form": form})

def signup_func(request):
    if request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()

            Customer.objects.create(
                user=user, 
                is_using_vehicle=False,
                start_using_time=None,
                end_using_time=None
            )
            return redirect("select_login")
    else:
        form = SignupForm()
    return render(request, "signup.html", {"form": form})

def logout_func(request):
    if request.method == "POST":
        logout(request)
        return redirect("home")

def password_change(request):
    if request.method == "POST":
        form = PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)

@login_required
def after_login_customer(request):
    user = User.objects.get(username=request.user.username)
    customer = Customer.objects.get(user=user)
    
    return render(request, "after_login_customer.html", {"customer": customer})
    
@login_required
def after_login_operator(request):
    user = User.objects.get(username=request.user.username)
    operator = Operator.objects.get(user=user)
    return render(request, "after_login_operator.html")
    
@login_required
def after_login_manager(request):
    user = User.objects.get(username=request.user.username)
    manager = Manager.objects.get(user=user)
    return render(request, "after_login_manager.html")

def rent_vehicle(request):
    if request.method == "POST":
        vehicle_id = request.POST.get('vehicle_id')
        try:
            user = User.objects.get(username=request.user.username)
            # print(request.user.username)
            customer = Customer.objects.get(user=user)
        except Customer.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'You are not Customer'})

        try:
            vehicle = Vehicle.objects.get(id=vehicle_id)
            
            if vehicle.is_in_use:
                return JsonResponse({'success': False, 'message': 'This vechicle is already been rented'})
            
            customer.is_using_vehicle = True
            customer.vehicle = vehicle
            customer.start_using_time = int(timezone.now().timestamp())
            customer.save()

            vehicle.is_in_use = True
            vehicle.save()

            return JsonResponse({'success': True})
        except Vehicle.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Vehicle does not found'})
    
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)

def return_vehicle(request):
    if request.method == "POST":
        customer = Customer.objects.get(user=request.user)
        if customer.is_using_vehicle:
            vehicle = customer.vehicle
            if vehicle:
                vehicle.is_in_use = False
                vehicle.save()
            
            customer.is_using_vehicle = False
            customer.end_using_time = int(timezone.now().timestamp())
            customer.vehicle = None
            customer.save()

            return JsonResponse({'success': True})

    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)