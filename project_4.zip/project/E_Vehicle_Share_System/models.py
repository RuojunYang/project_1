from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.hashers import make_password
# Create your models here.

class User(AbstractUser):
    class Types(models.TextChoices):
        CUSTOMER = "CUSTOMER", "Customer"
        OPERATOR = "OPERATOR", "Operator"
        MANAGER = "MANAGER", "Manager"
        
    type = models.CharField(
        max_length=50,
        choices=Types.choices,
        default=Types.CUSTOMER
    )

    def save(self, *args, **kwargs):
        if not self.pk and self.type is None:
            self.type = self.Types.CUSTOMER
        super().save(*args, **kwargs)

class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    password = models.CharField(max_length=128)
    start_using_time = models.BigIntegerField(null=True, blank=True)  # timestamp
    end_using_time = models.BigIntegerField(null=True, blank=True)
    is_using_vehicle = models.BooleanField(default=False)
    vehicle = models.ForeignKey('Vehicle', on_delete=models.SET_NULL, null=True, blank=True, related_name="current_customer")

    def save(self, *args, **kwargs):
        if self.password:
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.user.username
    
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['is_using_vehicle', 'vehicle'], name='unique_customer_use_per_vehicle')
        ]


class Operator(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    password = models.CharField(max_length=128)
    shift_start = models.TimeField(null=True, blank=True)
    shift_end = models.TimeField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if self.password:
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.user.username

class Manager(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    password = models.CharField(max_length=128)
    department = models.CharField(max_length=100, null=True, blank=True)

    def save(self, *args, **kwargs):
        if self.password:
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.user.username
    
class Vehicle(models.Model):
    id = models.AutoField(primary_key=True)
    is_in_use = models.BooleanField(default=False)
    customer = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="vehicles")
    
    def __str__(self):
        return f"Vehicle {self.id} - {'In Use' if self.is_in_use else 'Available'}"
    
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['is_in_use', 'customer'], name='unique_vehicle_use_per_customer')
        ]