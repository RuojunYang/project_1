from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User


class SignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']  # 只包含需要的字段

    def save(self, commit=True):
        user = super().save(commit=False)
        user.type = User.Types.CUSTOMER  # 将类型设置为 Customer
        if commit:
            user.save()
        return user
    

