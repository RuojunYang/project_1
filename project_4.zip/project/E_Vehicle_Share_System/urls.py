from django.urls import path
from . import views

urlpatterns = [

    path('', views.home, name='home'),

    path('select_login/', views.select_login, name="select_login"),
    path('login_customer/', views.login_customer, name="login_customer"),
    path('login_operator/', views.login_operator, name="login_operator"),
    path('login_manager/', views.login_manager, name="login_manager"),
    path('signup/', views.signup_func, name="signup"),
    path('logout/', views.logout_func, name="logout"),
    path('after_login_customer/', views.after_login_customer, name="after_login_customer"),
    path('after_login_operator/', views.after_login_operator, name="after_login_operator"),
    path('after_login_manager/', views.after_login_manager, name="after_login_manager"),
    path('rent_vehicle/', views.rent_vehicle, name='rent_vehicle'),
    path('return_vehicle/', views.return_vehicle, name='return_vehicle'),
]
