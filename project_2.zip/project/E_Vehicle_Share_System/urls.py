from django.urls import path
from . import views

urlpatterns = [

    path('', views.home, name='home'),

    path('login/', views.login_func, name="login"),
    path('signup/', views.signup_func, name="signup"),
    path('logout/', views.logout_func, name="logout"),
    path('after_login_home/', views.after_login_home, name="after_login_home"),
]
