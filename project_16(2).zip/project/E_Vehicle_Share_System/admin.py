# python manage.py makemigrations
# python manage.py migrate
# python manage.py createsuperuser
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Customer, Operator, Manager, Vehicle
from django.utils import timezone
import numpy as np
from geopy.geocoders import Nominatim
from decimal import Decimal

lon_max = -4.05
lon_min = -4.41	
lat_max = 55.94
lat_min = 55.73

def get_address(latitude, longitude):
    geolocator = Nominatim(user_agent="geoapi")
    location = geolocator.reverse((latitude, longitude), exactly_one=True)
    try :
        return location.address
    except Exception as e:
        print(e)

def cal_dis(lat1, lon1, lat2, lon2):
    lat1 = float(lat1)
    lon1 = float(lon1)
    lat2 = float(lat2)
    lon2 = float(lon2)
    R = 6371e3
    X = lat1 * np.pi/180
    Y = lat2 * np.pi/180
    M = (lat2-lat1) * np.pi/180
    N = (lon2-lon1) * np.pi/180
    a = np.sin(M/2) * np.sin(M/2) + np.cos(X) * np.cos(Y) * np.sin(N/2) * np.sin(N/2) 
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1-a))
    d = R * c
    return d

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'type')
    ordering = ('username',)

@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ('id', 'is_in_use', 'customer')
    ordering = ('id',)


# create test data
# operator
new_user, created_user = User.objects.get_or_create(
    username='operator',
    defaults={
        'password': 'password123',
        'type': User.Types.OPERATOR
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

    operator_instance, created_operator = Operator.objects.get_or_create(
        user=new_user,
        defaults={
        }
    )

# manager
new_user, created_user = User.objects.get_or_create(
    username='manager',
    defaults={
        'password': 'password123',
        'type': User.Types.MANAGER
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

    manager_instance, created_manager = Manager.objects.get_or_create(
        user=new_user,
        defaults={
        }
    )

# lon_max = -4.05
# lon_min = -4.41	
# lat_max = 55.94
# lat_min = 55.73

# customer
new_user, created_user = User.objects.get_or_create(
    username='customer',
    defaults={
        'password': 'password123',
        'type': User.Types.CUSTOMER
    }
)

if created_user:
    new_user.set_password('password123')
    new_user.save()

    lat = Decimal(np.random.uniform(lat_max, lat_min))
    lon = Decimal(np.random.uniform(lon_max, lon_min))

    customer_instance, created_customer = Customer.objects.get_or_create(
        user=new_user,
        defaults={
            'is_using_vehicle': False, 
            'start_using_time': 1729333602, 
            'end_using_time': 1729333902, 
            'charge': '110',
            'lat': lat,
            'lon': lon,
        }
    )

    for i in range(2):
        try:
            lat = Decimal(np.random.uniform(lat_max, lat_min))
            lon = Decimal(np.random.uniform(lon_max, lon_min))
            location = get_address(lat, lon)
            vehicle, created_vehicle = Vehicle.objects.get_or_create(
                id = i+10000,
                defaults={
                    'is_in_use': False,
                    'status_type': Vehicle.STATUS_TYPES.NOT_USING,
                    'vehicle_type': Vehicle.VEHICLE_TYPES.BIKE,
                    'lat': lat,
                    'lon': lon,
                    'location': location
                }
            )
            print(vehicle, vehicle.vehicle_type, vehicle.lat, vehicle.lon)
        except Exception as e:
            print(e)
    for i in range(2):
        try:
            lat = Decimal(np.random.uniform(lat_max, lat_min))
            lon = Decimal(np.random.uniform(lon_max, lon_min))
            location = get_address(lat, lon)
            vehicle, created_vehicle = Vehicle.objects.get_or_create(
                id = i+20000,
                defaults={
                    'is_in_use': False,
                    'status_type': Vehicle.STATUS_TYPES.DEFECTIVE,
                    'vehicle_type': Vehicle.VEHICLE_TYPES.SCOOTER,
                    'lat': lat,
                    'lon': lon,
                    'location': location,
                    'battery_level': 50
                }
            )
            print(vehicle, vehicle.vehicle_type, vehicle.lat, vehicle.lon)
        except Exception as e:
            print(e)

    for i in range(2):
        try:
            lat = Decimal(np.random.uniform(lat_max, lat_min))
            lon = Decimal(np.random.uniform(lon_max, lon_min))
            location = get_address(lat, lon)
            vehicle, created_vehicle = Vehicle.objects.get_or_create(
                id = i+30000,
                defaults={
                    'is_in_use': False,
                    'status_type': Vehicle.STATUS_TYPES.NOT_USING,
                    'vehicle_type': Vehicle.VEHICLE_TYPES.SCOOTER,
                    'lat': lat,
                    'lon': lon,
                    'location': location,
                    'battery_level': 0
                }
            )
            print(vehicle, vehicle.vehicle_type, vehicle.lat, vehicle.lon)
        except Exception as e:
            print(e)

    for i in range(2):
        try:
            lat = customer_instance.lat+Decimal((np.random.rand()-0.5)*0.00001)
            lon = customer_instance.lon+Decimal((np.random.rand()-0.5)*0.00001)
            location = get_address(lat, lon)
            vehicle, created_vehicle = Vehicle.objects.get_or_create(
                id = i+40000,
                defaults={
                    'is_in_use': False,
                    'status_type': Vehicle.STATUS_TYPES.NOT_USING,
                    'vehicle_type': Vehicle.VEHICLE_TYPES.BIKE,
                    'lat': lat,
                    'lon': lon,
                    'location': location,
                    'battery_level': 30
                }
            )
            print(vehicle, vehicle.vehicle_type, vehicle.lat, vehicle.lon)
        except Exception as e:
            print(e)
        try:
            lat = customer_instance.lat+Decimal((np.random.rand()-0.5)*0.00001)
            lon = customer_instance.lon+Decimal((np.random.rand()-0.5)*0.00001)
            print(lat, lon)
            location = get_address(lat, lon)
            vehicle, created_vehicle = Vehicle.objects.get_or_create(
                id = i+50000,
                defaults={
                    'is_in_use': False,
                    'status_type': Vehicle.STATUS_TYPES.NOT_USING,
                    'vehicle_type': Vehicle.VEHICLE_TYPES.SCOOTER,
                    'lat': lat,
                    'lon': lon,
                    'location': location,
                    'battery_level': 50
                }
            )
            print(vehicle, vehicle.vehicle_type, vehicle.lat, vehicle.lon)
        except Exception as e:
            print(e)

    print(customer_instance.lat, customer_instance.lon)